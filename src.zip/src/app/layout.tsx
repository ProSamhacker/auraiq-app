import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// MODIFICATION: Updated the title and description for your app
export const metadata: Metadata = {
  title: "AuraIQ",
  description: "Your intelligent AI assistant",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      {/* MODIFICATION: Added the <head> section with manifest and theme color */}
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#131314" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}