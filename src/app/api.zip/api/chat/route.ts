// src/app/api/chat/route.ts

import { NextRequest, NextResponse } from "next/server";
import { put } from '@vercel/blob';
import { randomUUID } from "crypto";

export const runtime = "nodejs";

type HistoryMessage = {
  id: string;
  text: string;
  sender: 'user' | 'ai';
};

const isTextBased = (file: File): boolean => {
  const textMimeTypes = ['text/', 'application/json', 'application/javascript'];
  return textMimeTypes.some(type => file.type.startsWith(type));
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const input = formData.get('input') as string;
    const taskType = formData.get('taskType') as string;
    const context = formData.get('context') as string;
    const historyString = formData.get('history') as string;
    const history = JSON.parse(historyString || '[]') as HistoryMessage[];
    const files = formData.getAll('files') as File[];
    
    let textContent = input;
    const imageContent: { type: 'image_url'; image_url: { url: string } }[] = [];
    let hasImage = false;

    if (files.length > 0) {
      const filePromises = files.map(async (file) => {
        if (file.type.startsWith('image/')) {
          hasImage = true;
          const uniqueFilename = `${randomUUID()}-${file.name}`;
          const blob = await put(uniqueFilename, file, { access: 'public' });
          imageContent.push({ type: 'image_url', image_url: { url: blob.url } });
        } else if (isTextBased(file) && file.size < 1000000) { 
          const fileText = await file.text();
          textContent += `\n\n--- Content of ${file.name} ---\n${fileText}\n--- End of ${file.name} ---`;
        }
      });
      await Promise.all(filePromises);
    }
    
    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) throw new Error("OpenRouter API key is not configured.");
    
    let modelName = "";
    const visionModel = "qwen/qwen2.5-vl-72b-instruct:free";
    const dailyTaskModel = "meta-llama/llama-3.3-70b-instruct:free";
    const codingTaskModel = "qwen/qwen-2.5-coder-32b-instruct:free";

    if (hasImage) {
      modelName = visionModel;
    } else if (taskType === 'daily') {
      modelName = dailyTaskModel;
    } else if (taskType === 'coding') {
      modelName = codingTaskModel;
    } else {
      const codingKeywords = ['code', 'python', 'javascript', 'error', 'debug', 'react'];
      const isCodingRequest = codingKeywords.some(keyword => new RegExp(`\\b${keyword}\\b`, 'i').test(textContent));
      modelName = isCodingRequest ? codingTaskModel : dailyTaskModel;
    }

    const apiUrl = "https://openrouter.ai/api/v1/chat/completions";

    const formattedHistory = history.map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'assistant',
      content: msg.text
    }));

    const systemMessage = { role: "system", content: context || "You are AuraIQ, a helpful and intelligent AI assistant." };

    // --- MODIFICATION: Build valid multi-modal payload ---
    const userMessageContent = [];

    // If there's an image but no text prompt, add a default one.
    // Otherwise, add the user's text prompt if it exists.
    if (hasImage && !textContent.trim()) {
        userMessageContent.push({ type: 'text', text: 'Describe this image in detail.' });
    } else if (textContent.trim()) {
        userMessageContent.push({ type: 'text', text: textContent });
    }

    // Add the image content if it exists
    if (imageContent.length > 0) {
        userMessageContent.push(...imageContent);
    }
    
    // Final check to ensure we are not sending an empty message
    if (userMessageContent.length === 0) {
        return NextResponse.json({ error: "Input is empty." }, { status: 400 });
    }
    // --- End of Modification ---

    const payload = {
      model: modelName,
      messages: [
        systemMessage,
        ...formattedHistory,
        { role: "user", content: userMessageContent }
      ],
      stream: true
    };

    const upstream = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        "HTTP-Referer": "https://auraiq-app.vercel.app", 
        "X-Title": "AuraIQ"
      },
      body: JSON.stringify(payload)
    });

    if (!upstream.ok || !upstream.body) {
        const errorBody = await upstream.text();
        console.error("OpenRouter API Error:", errorBody);
        // MODIFICATION: Pass the actual error from OpenRouter to the frontend
        return NextResponse.json({ error: `OpenRouter API error: ${errorBody}` }, { status: upstream.status });
    }
    
    const stream = new ReadableStream({
        async start(controller) {
          const reader = upstream.body!.getReader();
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              controller.enqueue(value);
            }
          } catch (err) {
            console.error("Error while reading upstream stream:", err);
          } finally {
            controller.close();
          }
        }
      });
  
      return new Response(stream, {
        headers: { "Content-Type": "text/event-stream; charset=utf-8" }
      });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("Error in /api/chat:", errorMessage);
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}